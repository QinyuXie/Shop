import React from 'react';
import ProductList from './ProductList';

const Product = () => {
    return (
        <div>
            <ProductList />
        </div>
    );
} 

export default Product;